<!DOCTYPE html>
<html>
<head>
	<title>Regitration</title>
</head>
<body>
     
     <div class="container">
     	
        <div class="header">
        	<h2>Register</h2>
        </div>

        <form action="Ganesh.php" method="post">
        	<div>
        		<label for="username">Username</label>
        		<input type="text" name="username">
        	</div>
            <div>
        		<label for="email">E-mail Id</label>
        		<input type="E-mail" name="email">
        	</div>
        	<div>
        		<label for="password">Password</label>
        		<input type="password" name="password_1">
        	</div>
        	<div>
        		<label for="password">Re-enter Password</label>
        		<input type="text" name="password_2">
        	</div>
        	<div>
        		<button type="submit">Submit</button>
        	</div>
 







        </form>






     </div>

         







</body>
</html>